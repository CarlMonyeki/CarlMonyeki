import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.Test;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.replaceFiltersWith;
import static org.hamcrest.Matchers.equalTo;

public class API_Test {

    @Test
    public  void ReturnGDP(){
        RestAssured.baseURI = " https://api.coindesk.com/v1/bpi/currentprice.json";

        Response response = given()
                .when()
                .get("/currentprice.json")
                .then()
                .statusCode(200)
                .body("code", equalTo("GBP"))
                .extract()
                .response();

        System.out.println("Status: " + response.getStatusCode());
        System.out.println("Body: " + response.getBody());


    }



}
