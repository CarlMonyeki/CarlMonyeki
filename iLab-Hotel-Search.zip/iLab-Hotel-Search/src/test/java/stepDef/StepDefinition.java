package stepDef;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.velocity.util.introspection.VelPropertySet;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class StepDefinition {
    WebDriver driver;

    @Before
    public void initializeDriver() {
        ChromeOptions  options = new ChromeOptions();
        driver = new ChromeDriver();
    }

    @Given("User navigate to home page")
    public void user_navigate_to_home_page() {
        driver.get("http://adactinhotelapp.com/");
        driver.manage().window().maximize();
    }

    @When("User logs in with valid username and password {string} {string}")
    public void user_logs_in_with_valid_username_and_password(String userName,String password) {
        driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(userName);
        driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(password);
        driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
    }

    @Then("User select  location")
    public void user_select_location() {
        WebElement webElement = driver.findElement(By.name("location"));
    Select dropDown = new Select(webElement);
    dropDown.selectByVisibleText("London");
    }
    @Then("user select a hotel")
    public void user_select_a_hotel() {
        WebElement webElement = driver.findElement(By.name("hotels"));
        Select dropDown = new Select(webElement);
        dropDown.selectByVisibleText("Hotel Hervey");
    }
    @Then("User select room type")
    public void user_select_room_type() {
        WebElement webElement = driver.findElement(By.name("room_type"));
        Select dropDown = new Select(webElement);
        dropDown.selectByVisibleText("Super Deluxe");
    }
    @Then("User select number of rooms")
    public void user_select_number_of_rooms() {
        WebElement webElement = driver.findElement(By.name("room_nos"));
        Select dropDown = new Select(webElement);
        dropDown.selectByValue("5");
    }
    @Then("User input checkIn date")
    public void user_input_check_in_date() {
        driver.findElement(By.xpath("//*[@id=\"datepick_in\"]")).clear();
        driver.findElement(By.xpath("//*[@id=\"datepick_in\"]")).sendKeys("03/04/2024");
    }
    @Then("User input checkOut date")
    public void user_input_check_out_date() {
        driver.findElement(By.xpath("//*[@id=\"datepick_out\"]")).clear();
        driver.findElement(By.xpath("//*[@id=\"datepick_out\"]")).sendKeys("04/04/2024");

    }
    @Then("User select number of adults per room")
    public void user_select_number_of_adults_per_room() {
        WebElement webElement = driver.findElement(By.name("adult_room"));
        Select dropDown = new Select(webElement);
        dropDown.selectByValue("3");
    }
    @Then("User select number of children per room")
    public void user_select_number_of_children_per_room() {
        WebElement webElement = driver.findElement(By.name("child_room"));
        Select dropDown = new Select(webElement);
        dropDown.selectByValue("3");
    }
    @Then("User clicks search")
    public void user_clicks_search() {

        driver.findElement(By.xpath("//*[@id=\"Submit\"]")).click();

        if (driver.findElement(By.xpath("//*[@id=\"hotel_name_0\"]")).isDisplayed()) {
            System.out.println("Validate Data Returned");

        }
        else
            System.out.println("Invalidate Data Returned");

    }


}
