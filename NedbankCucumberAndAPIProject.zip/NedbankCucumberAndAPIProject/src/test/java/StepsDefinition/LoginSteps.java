package StepsDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginSteps {
    WebDriver driver;
    @Given("I am on automation test site")
    public void iAmOnAutomationTestSite() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://eqaroloflow.co.za/wp/");

    }

    @And("I click my account link")
    public void iClickMyAccountLink() {

        driver.findElement(By.xpath("//*[@id=\"menu-item-57\"]/a")).click();
    }

    @When("^I enter valid (.*) and (.*)$")
    public void iEnterValidUsernameAndPassword(String uid, String pass) {
        driver.findElement(By.id("username")).sendKeys(uid);
        driver.findElement(By.id("password")).sendKeys(pass);
    }

    @And("I click login button")
    public void iClickLoginButton() {
        driver.findElement(By.name("login")).click();

    }




}
