package StepsDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyStepdefs {

    WebDriver driver;
    @Given("I am on pizza website home page")
    public void iAmOnPizzaWebsiteHomePage() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("http://eqaroloflow.co.za/");
        driver.manage().window().maximize();

    }

    @When("I enter <username> and <password>")
    public void iEnterUsernameAndPassword(String uid, String pass) {
        driver.findElement(By.id("username")).sendKeys(uid);
        driver.findElement(By.id("password")).sendKeys(pass);
        driver.findElement(By.id("login")).click();
    }

    @Then("I click shop link")
    public void iClickShopLink() {
        driver.findElement(By.xpath("shop_link")).click();
    }

    @And("I select wine item")
    public void iSelectWineItem() {
        driver.findElement(By.xpath("wine")).click();
    }

    @And("I click checkout and place the order")
    public void iClickCheckoutAndPlaceTheOrder() {
        driver.findElement(By.id("username")).click();
    }

    @Then("I print the order number")
    public void iPrintTheOrderNumber() {
    }
}
